from django.contrib import admin
from .models import UserDetail

# Register your models here.
class UserDetailList(admin.ModelAdmin):
    list_display = [field.name for field in UserDetail._meta.get_fields()]


admin.site.register(UserDetail, UserDetailList)