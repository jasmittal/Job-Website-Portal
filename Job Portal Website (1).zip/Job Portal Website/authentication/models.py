from django.db import models
from django.contrib.auth import get_user_model

from mainproject.utils.db_models import CommonModel

User = get_user_model()

# Create your models here.
class UserDetail(CommonModel):
    GENDER_CHOICES = (('male', 'male'), ('female', 'female'))
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='details')
    picture = models.ImageField(upload_to='images/users', blank=True, null=True)
    occupation = models.CharField(max_length=30)
    bio = models.TextField(max_length=500, blank=True, null=True)
    skills = models.CharField(max_length=255, blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    education = models.CharField(max_length=255, blank=True, null=True)
    experience = models.TextField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=50, choices=GENDER_CHOICES)
