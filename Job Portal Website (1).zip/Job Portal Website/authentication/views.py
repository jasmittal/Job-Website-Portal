from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth.hashers import check_password

# Create your views here.

class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')
    
    def post(self, request):
        username = request.POST['username']
        password = request.POST['password']

        data = {'username':username, 'password':password}

        user = authenticate(request, username=username, password=password)
        user_obj = User.objects.filter(username=username)
        if not user_obj:
            messages.add_message(request, messages.ERROR, 'Invalid username. Did you forget to register on Website?')
            return redirect('authentication:Login')
        
        if user:
            login(request, user)
            messages.add_message(request, messages.SUCCESS, 'Login Successfully !')

            # # --------- send mail --------------

            # subject = f'Welcome {user.username.title()} !'
            # message = f'Hey {user.username.title()}, You are logged in successfully in Our Website !'
            # email_from = settings.EMAIL_HOST_USER
            # recipient_list = [user.email, ]
            # send_mail(subject, message, email_from, recipient_list)

            return redirect('mainapp:Home')

        else:
            messages.add_message(request, messages.ERROR, 'Invalid password.')

            return render(request, 'login.html', {'data':data})
    

class SignupView(View):
    def get(self, request):
        return render(request, 'signup.html')
    
    def post(self, request):
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        val = {'first_name':first_name, 'last_name':last_name, 'username':username,'email':email, 'is_active':True}

        new_user = User.objects.filter(username=username)

        if new_user.exists():
            messages.add_message(request, messages.ERROR, 'Username already esists. Please try another username')
            return render(request, 'signup.html', {'data':val})
        else:
            user = User.objects.create(**val)
            user.set_password(password)
            user.save()
            # # --------------- send mail ----------------

            # subject = f'Welcome {user.username.title()} !'
            # message = f'Hi {user.username.title()}, Thank you for registering in Our Website !'
            # email_from = settings.EMAIL_HOST_USER
            # recipient_list = [user.email, ]
            # send_mail( subject, message, email_from, recipient_list )
        
        messages.add_message(request, messages.SUCCESS, 'Registered Successfully.')
        return redirect('authentication:Login')
    

class LogoutView(View):
    def post(self, request):
        logout(request)
        messages.add_message(request, messages.SUCCESS, 'Logged out Successfully !')
        return redirect('authentication:Login')


class ChangePasswordView(View):
    def get(self, request):
        return render(request, 'change_password.html')
    
    def post(Self, request):
        old_password = request.POST['oldpassword']
        new_password = request.POST['newpassword']
        confirm_new_password = request.POST['confirmnewpassword']

        data = {'old_password':old_password, 'new_password':new_password, 'confirm_new_password':confirm_new_password}

        if check_password(old_password, request.user.password):
            if old_password != new_password:
                if new_password == confirm_new_password:
                    messages.add_message(request, messages.SUCCESS, 'Password Match')
                    obj = User.objects.get(username=request.user.username)
                    obj.set_password(new_password)
                    obj.save()
                    messages.add_message(request, messages.SUCCESS, 'Password Changed Successfully !')
                    logout(request)
                    return redirect('authentication:Login')
                else:
                    messages.add_message(request, messages.ERROR, 'Password and New Password should be same !')
                    return render(request, 'change_password.html', {'data':data})
            else:
                messages.add_message(request, messages.ERROR, 'Old Password and New Password should be different !')
                return render(request, 'change_password.html', {'data':data})
        else:
            messages.add_message(request, messages.ERROR, 'Old Password Does not match')

            return render(request, 'change_password.html', {'data':data})
              

class ForgetPasswordView(View):
    def get(self, request):
        return render(request, 'forget_password.html')
