// message
$("#message-close-icon").click(function() {
    $(".message").css( {"display":"none"} );
});

// $(document).ready(function(){
//     // Hide the message
//     setTimeout(function(){$("#message").hide();}, 5000); // 5000 milliseconds = 5 seconds
// });

// ----------------------- navbar ------------------------
$("#menu-icon").click(function() {
    $("#close-icon").css( {"display": "block"} );
    $("#menu-icon").css( {"display": "none"} );
    $(".links").removeClass("links").addClass("links-display").css( {"left": "0"} );
});
$("#close-icon").click(function() {
    $("#menu-icon").css( {"display": "block"} );
    $("#close-icon").css( {"display": "none"} );
    $(".links-display").removeClass("links-display").addClass("links");
});


// user
$("#user_button").click(function(){
    let contentShow = $('.login_user_options').css("visibility");

    if (contentShow == "hidden"){
        $(".login_user_options").css( {"visibility":"visible", "opacity":"1", "right": "0"} );
    }else{
        $(".login_user_options").css( {"visibility":"hidden", "opacity":"0", "right": "-300px"} );
    }
});

// Password input
$(".password-show").click(function() {
    $(this).closest('.password-input').find('input').attr("type", ($("input").attr("type") === "text") ? "password" : "text");
    $(this).closest('.password-input').find('.password-show').css( {"display": "none"} )
    $(this).closest('.password-input').find('.password-hide').css( {"display": "block"} )
})
$(".password-hide").click(function() {

    $(this).closest('.password-input').find('input').attr("type", ($("input").attr("type") === "password") ? "text" : "password");
    $(this).closest('.password-input').find('.password-hide').css( {"display": "none"} )
    $(this).closest('.password-input').find('.password-show').css( {"display": "block"} )
})