import codecs

input_file = 'all_data.json'
output_file = 'all_data_utf8.json'

# Read the original file with its original encoding
with codecs.open(input_file, 'r', encoding='utf-16') as file:
    data = file.read()

# Write the data to a new file with UTF-8 encoding
with codecs.open(output_file, 'w', encoding='utf-8') as file:
    file.write(data)

print(f"File has been converted and saved as {output_file}")
