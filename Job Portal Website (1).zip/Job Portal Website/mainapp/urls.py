"""
URL configuration for mainproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from django.contrib.auth.decorators import login_required

from .views import main_views as mv
from .views import user_views as uv
from .views import category_views as cv

app_name = 'mainapp'

urlpatterns = [
    path('', mv.HomeView.as_view(), name='Home'),

    path('job/', login_required(mv.JobView.as_view()), name='Job'),
    path('job/<str:category>-jobs/', cv.JobListingView.as_view(), name='Job-Category'),

    path('about/', login_required(mv.AboutView.as_view()), name='About'),
    path('testimonial/', login_required(mv.TestimonialView.as_view()), name='Testimonial'),

    path('profile/', login_required(uv.ProfileView.as_view()), name='Profile'),
    path('applied/', login_required(uv.AppliedJobsView.as_view()), name='Applied'),
]

urlpatterns += [
    path('job-apply/<int:pk>/', login_required(cv.ApplyJobView.as_view()), name='ApplyToJobFromId'),
    path('job-remove/<int:pk>/', login_required(uv.RemoveJob.as_view()), name='RemoveJobApi'),
]
