from django.contrib import admin
from .models import JobCategory, Job, AppliedJob

class JobCategoryListing(admin.ModelAdmin):
    list_display = ('id', 'title', 'description', 'created_at', 'updated_at', )

class JobListing(admin.ModelAdmin): 
    list_display = ('id', 'title', 'skills', 'description', 'type', 'shift', 'location')

class AppliedJobListing(admin.ModelAdmin): 
    list_display = ('id', 'user', 'job')


# Register your models here.
admin.site.register(JobCategory, JobCategoryListing)
admin.site.register(Job, JobListing)
admin.site.register(AppliedJob, AppliedJobListing)
