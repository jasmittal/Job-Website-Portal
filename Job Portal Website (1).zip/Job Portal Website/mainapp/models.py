from django.db import models
from django.contrib.auth.models import User
from mainproject.utils.db_models import CommonModel
from django.utils import timezone

# Create your models here.
class JobCategory(CommonModel):
    title = models.CharField(max_length=50, unique=True,help_text="Only use alphabets.Avoid using '!@#$%^&*()' etc.")
    description = models.TextField()

    def __str__(self):
        return self.title
    

    def save(self, *args, **kwargs):
        if self.id:
            super(JobCategory, self).save(*args, **kwargs)
        else:
            self.title = ' '.join(self.title.lower().split())
            self.description = ' '.join(self.description.lower().split())
            super(JobCategory, self).save(*args, **kwargs)


class Job(CommonModel):
    TYPE_CHOICES = (('full time', 'full time'), ('part time', 'part time'), ('internship', 'internship'), ('training', 'training'))
    SHIFT_CHOICES = (('day shift', 'day shift'), ('night shift', 'night shift'),)
    LOCATION_CHOICES = (('chandigarh', 'chandigarh'), ('mohali', 'mohali'), (('gurugram', 'gurugram')), ('panchkula', 'panchkula'), ('delhi', 'delhi'), ('noida', 'noida'),)

    title = models.CharField(max_length=50, help_text="Only use alphabets.Avoid using '!@#$%^&*()' etc.")
    skills = models.CharField(max_length=50)
    description = models.TextField()
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    shift = models.CharField(max_length=20, choices=SHIFT_CHOICES)
    location = models.CharField(max_length=20, choices=LOCATION_CHOICES)
    job_category = models.ForeignKey(JobCategory, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        if self.id:
            super(Job, self).save(*args, **kwargs)
        else:
            self.title = ' '.join(self.title.lower().split())
            self.skills = ' '.join(self.skills.lower().split())
            self.description = ' '.join(self.description.lower().split())
            super(Job, self).save(*args, **kwargs)


class AppliedJob(CommonModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)

    def __str__(self):
        return self.job.title
