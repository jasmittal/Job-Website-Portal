from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from mainapp.models import AppliedJob
from authentication.models import User

# Create your views here.
class ProfileView(View):
    def get(self, request):
        return render(request, 'user/profile.html')


class AppliedJobsView(View):
    def get(self, request):
        applied_jobs = AppliedJob.objects.all().order_by("-created_at")
        job_data = []
        for i in applied_jobs:
            job_data.append(
                {
                    "id": i.id,
                    "job_title": i.job.title,
                    "job_description": i.job.description,
                    "job_skills": i.job.skills.split(","),
                    "job_shift": i.job.shift,
                    "job_type": i.job.type,
                    "job_location": i.job.location,
                    "created_at": i.created_at
                }
            )
        return render(request, 'user/applied.html', {'applied_jobs': applied_jobs, "job_data": job_data, "applied_jobs_count": applied_jobs.count()})


class RemoveJob(View):
    def post(self, request, pk):
        AppliedJob.objects.get(id=pk).delete()
        messages.add_message(request, messages.SUCCESS, 'Job removed successfully')
        return redirect('mainapp:Job')
