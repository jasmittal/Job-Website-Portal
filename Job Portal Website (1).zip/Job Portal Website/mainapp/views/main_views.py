from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from mainapp.models import JobCategory, Job

# Create your views here.
model_name = JobCategory

class HomeView(View):
    def get(self, request):
        messages.add_message(request, messages.SUCCESS, 'Welcome to "JobSearch"')
        return render(request, 'home.html')
    

class JobView(View):
    def get(self, request):
        categories_all = model_name.objects.all()
        return render(request, 'job.html', {'categories_all':categories_all,})
    

class AboutView(View):
    def get(self, request):
        return render(request, 'about.html')
    

class TestimonialView(View):
    def get(self, request):
        return render(request, 'testimonial.html')
