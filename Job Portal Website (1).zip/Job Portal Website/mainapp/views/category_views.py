from django.shortcuts import render, redirect
from django.contrib import messages
from django.views import View
from mainapp.models import Job, JobCategory, AppliedJob

main_path = 'category'
model_name = JobCategory

class JobListingView(View):
    def get(self, request, category=None):
        category_title = ' '.join(category.split('-'))
        categories_all = model_name.objects.all()
        jobs_all = model_name.objects.get(title=category_title).job_set.all()
        job_listing = model_name.objects.get(title=category_title)
        job_skills = []
        job_skills_all = []
        for i in jobs_all:
            job_skills_all.extend((i.skills.split(', ')))
        for i in job_skills_all:
            if i not in job_skills:
                job_skills.append(i)

        return render(request, f'{main_path}/job_listing.html', {'categories_all':categories_all, 'jobs_all':jobs_all, 'job_listing':job_listing, 'category_title':category_title, 'jobs_all':jobs_all, 'job_skills':job_skills})


class ApplyJobView(View):
    def post(self, request, pk=None):
        already_applied_check = AppliedJob.objects.filter(user=request.user, job=Job.objects.get(id=pk))
        if already_applied_check:
            messages.add_message(request, messages.SUCCESS, 'You have already applied to this Job')
        else:
            AppliedJob.objects.create(user=request.user, job=Job.objects.get(id=pk))
            messages.add_message(request, messages.SUCCESS, 'Applied successfully')
        return redirect('mainapp:Applied')
